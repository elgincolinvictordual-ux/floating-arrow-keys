package com.floatingkeys;

interface IKeyService {
    // Transaction id 16777114 is reserved by Shizuku for destroy()
    void destroy() = 16777114;

    boolean key(int keyCode, boolean down) = 1;
}
