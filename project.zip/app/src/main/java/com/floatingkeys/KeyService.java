package com.floatingkeys;

import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import android.util.SparseLongArray;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;

import java.lang.reflect.Method;

/**
 * Runs inside the Shizuku process (shell identity), so it is allowed to inject
 * real key events into whatever app is in the foreground.
 */
public class KeyService extends IKeyService.Stub {

    private static final String TAG = "FloatingKeys";

    private Object target;
    private Method inject;
    private final SparseLongArray downTimes = new SparseLongArray();

    public KeyService() {
        try {
            setupBinderRoute();
        } catch (Throwable t) {
            Log.w(TAG, "IInputManager route failed, trying InputManager", t);
            try {
                setupManagerRoute();
            } catch (Throwable t2) {
                Log.e(TAG, "No way to inject key events", t2);
            }
        }
    }

    private void setupBinderRoute() throws Exception {
        Class<?> sm = Class.forName("android.os.ServiceManager");
        IBinder binder = (IBinder) sm.getMethod("getService", String.class).invoke(null, "input");
        Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
        target = stub.getMethod("asInterface", IBinder.class).invoke(null, binder);
        inject = target.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
    }

    private void setupManagerRoute() throws Exception {
        Class<?> im = Class.forName("android.hardware.input.InputManager");
        Method getInstance = im.getDeclaredMethod("getInstance");
        getInstance.setAccessible(true);
        target = getInstance.invoke(null);
        inject = im.getMethod("injectInputEvent", InputEvent.class, int.class);
    }

    @Override
    public void destroy() {
        System.exit(0);
    }

    @Override
    public boolean key(int keyCode, boolean down) {
        if (inject == null || target == null) {
            return false;
        }
        try {
            long now = SystemClock.uptimeMillis();
            long downTime;
            if (down) {
                downTime = now;
                downTimes.put(keyCode, now);
            } else {
                downTime = downTimes.get(keyCode, now);
            }
            KeyEvent event = new KeyEvent(
                    downTime,
                    now,
                    down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP,
                    keyCode,
                    0,
                    0,
                    KeyCharacterMap.VIRTUAL_KEYBOARD,
                    0,
                    0,
                    InputDevice.SOURCE_KEYBOARD);
            // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
            Object result = inject.invoke(target, event, 0);
            return !(result instanceof Boolean) || (Boolean) result;
        } catch (Throwable t) {
            Log.e(TAG, "Key injection failed", t);
            return false;
        }
    }
}
