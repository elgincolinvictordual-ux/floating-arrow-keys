package com.floatingkeys;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_SHIZUKU = 100;

    private TextView tvOverlay, tvRunning, tvPermission;
    private Button btnStart;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            new Shizuku.OnRequestPermissionResultListener() {
                @Override
                public void onRequestPermissionResult(int requestCode, int grantResult) {
                    refresh();
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("Floating Arrow Keys");
        title.setTextSize(24);
        col.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Floating arrows that send real key presses to games. "
                + "Needs Shizuku running (Wireless debugging).");
        hint.setPadding(0, pad / 2, 0, pad);
        col.addView(hint);

        tvOverlay = new TextView(this);
        tvRunning = new TextView(this);
        tvPermission = new TextView(this);
        col.addView(tvOverlay);
        col.addView(tvRunning);
        col.addView(tvPermission);

        col.addView(button("1. Allow draw over other apps", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        }));

        col.addView(button("2. Open Shizuku", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i != null) {
                    startActivity(i);
                } else {
                    Toast.makeText(MainActivity.this, "Shizuku is not installed",
                            Toast.LENGTH_LONG).show();
                }
            }
        }));

        col.addView(button("3. Allow Shizuku access", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (!Shizuku.pingBinder()) {
                        Toast.makeText(MainActivity.this, "Start Shizuku first",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    Shizuku.requestPermission(REQ_SHIZUKU);
                } catch (Throwable t) {
                    Toast.makeText(MainActivity.this, "Shizuku error: " + t.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
        }));

        btnStart = button("Start floating arrows", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggle();
            }
        });
        col.addView(btnStart);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);

        Shizuku.addRequestPermissionResultListener(permissionListener);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(permissionListener);
    }

    private boolean shizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean shizukuGranted() {
        try {
            return Shizuku.pingBinder()
                    && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String mark(boolean ok) {
        return ok ? "\u2705 " : "\u274C ";
    }

    private void refresh() {
        tvOverlay.setText(mark(Settings.canDrawOverlays(this)) + "Draw over other apps");
        tvRunning.setText(mark(shizukuRunning()) + "Shizuku is running");
        tvPermission.setText(mark(shizukuGranted()) + "Shizuku access for this app");
        btnStart.setText(OverlayService.running ? "Stop floating arrows" : "Start floating arrows");
    }

    private void toggle() {
        Intent svc = new Intent(this, OverlayService.class);
        if (OverlayService.running) {
            stopService(svc);
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow draw over other apps first", Toast.LENGTH_LONG).show();
                return;
            }
            if (!shizukuGranted()) {
                Toast.makeText(this, "Finish Shizuku steps first", Toast.LENGTH_LONG).show();
                return;
            }
            startForegroundService(svc);
        }
        btnStart.postDelayed(new Runnable() {
            @Override
            public void run() {
                refresh();
            }
        }, 300);
    }
}
