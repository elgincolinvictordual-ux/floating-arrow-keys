package com.floatingkeys;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;

import rikka.shizuku.Shizuku;

public class OverlayService extends Service {

    private static final String TAG = "FloatingKeys";
    private static final String CHANNEL_ID = "floating_keys";

    public static boolean running = false;

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private LinearLayout root;
    private LinearLayout pad;

    private IKeyService keys;
    private boolean bound = false;
    private Shizuku.UserServiceArgs userServiceArgs;
    private long lastToast = 0;
    private final Set<Integer> held = new HashSet<>();

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            if (binder != null && binder.pingBinder()) {
                keys = IKeyService.Stub.asInterface(binder);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            keys = null;
            bound = false;
        }
    };

    private final Shizuku.OnBinderReceivedListener binderListener = new Shizuku.OnBinderReceivedListener() {
        @Override
        public void onBinderReceived() {
            tryBind();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        startAsForeground();

        userServiceArgs = new Shizuku.UserServiceArgs(
                new ComponentName(getPackageName(), KeyService.class.getName()))
                .processNameSuffix("keys")
                .daemon(false)
                .debuggable(false)
                .version(1);

        buildOverlay();
        Shizuku.addBinderReceivedListenerSticky(binderListener);
        tryBind();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    private void tryBind() {
        if (bound || keys != null) {
            return;
        }
        try {
            if (!Shizuku.pingBinder()
                    || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            Shizuku.bindUserService(userServiceArgs, connection);
            bound = true;
        } catch (Throwable t) {
            Log.e(TAG, "Could not bind Shizuku user service", t);
        }
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL_ID, "Floating arrow keys", NotificationManager.IMPORTANCE_LOW));

        PendingIntent open = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Floating arrow keys")
                .setContentText("Tap to open and stop")
                .setSmallIcon(android.R.drawable.ic_menu_directions)
                .setContentIntent(open)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ------------------------------------------------------------------ UI

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, boolean round) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        if (round) {
            d.setShape(GradientDrawable.OVAL);
        } else {
            d.setCornerRadius(dp(12));
        }
        return d;
    }

    private void buildOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView bubble = new TextView(this);
        bubble.setText("KEYS");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(11);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(bg(0xCC1565C0, true));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(52), dp(52));
        bp.setMargins(dp(3), dp(3), dp(3), dp(3));
        root.addView(bubble, bp);

        pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(spacer());
        top.addView(keyButton("\u25B2", android.view.KeyEvent.KEYCODE_DPAD_UP));
        top.addView(spacer());

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(keyButton("\u25C0", android.view.KeyEvent.KEYCODE_DPAD_LEFT));
        bottom.addView(keyButton("\u25BC", android.view.KeyEvent.KEYCODE_DPAD_DOWN));
        bottom.addView(keyButton("\u25B6", android.view.KeyEvent.KEYCODE_DPAD_RIGHT));

        LinearLayout.LayoutParams wrap = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        pad.addView(top, new LinearLayout.LayoutParams(wrap));
        pad.addView(bottom, new LinearLayout.LayoutParams(wrap));
        root.addView(pad, new LinearLayout.LayoutParams(wrap));

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(24);
        lp.y = dp(240);

        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            int origX, origY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = e.getRawX();
                        startY = e.getRawY();
                        origX = lp.x;
                        origY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - startX;
                        float dy = e.getRawY() - startY;
                        if (!moved && Math.hypot(dx, dy) > slop) {
                            moved = true;
                        }
                        if (moved) {
                            lp.x = origX + (int) dx;
                            lp.y = origY + (int) dy;
                            wm.updateViewLayout(root, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            boolean show = pad.getVisibility() != View.VISIBLE;
                            pad.setVisibility(show ? View.VISIBLE : View.GONE);
                            wm.updateViewLayout(root, lp);
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });

        wm.addView(root, lp);
    }

    private View spacer() {
        View v = new View(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(60), dp(60));
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        v.setLayoutParams(p);
        return v;
    }

    private TextView keyButton(String glyph, final int keyCode) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setTextColor(Color.WHITE);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        t.setBackground(bg(0xAA222222, false));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(60), dp(60));
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        t.setLayoutParams(p);

        t.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setBackground(bg(0xFF2E7D32, false));
                        press(keyCode, true);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setBackground(bg(0xAA222222, false));
                        press(keyCode, false);
                        return true;
                    default:
                        return true;
                }
            }
        });
        return t;
    }

    private void press(int keyCode, boolean down) {
        if (keys == null) {
            tryBind();
            long now = System.currentTimeMillis();
            if (down && now - lastToast > 3000) {
                lastToast = now;
                Toast.makeText(this, "Shizuku not connected. Open the app to check.",
                        Toast.LENGTH_SHORT).show();
            }
            return;
        }
        try {
            if (down) {
                held.add(keyCode);
            } else {
                held.remove(keyCode);
            }
            keys.key(keyCode, down);
        } catch (RemoteException e) {
            Log.e(TAG, "key() failed", e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        running = false;

        if (keys != null) {
            for (Integer code : new HashSet<>(held)) {
                try {
                    keys.key(code, false);
                } catch (Throwable ignored) {
                }
            }
        }

        try {
            Shizuku.removeBinderReceivedListener(binderListener);
        } catch (Throwable ignored) {
        }
        try {
            if (bound) {
                Shizuku.unbindUserService(userServiceArgs, connection, true);
            }
        } catch (Throwable ignored) {
        }
        try {
            if (root != null) {
                wm.removeView(root);
            }
        } catch (Throwable ignored) {
        }
    }
}
